﻿using ManageAppCrud.Data;
using ManageAppCrud.Models;
using ManageAppCrud.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManageAppCrud.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeService _employeeService;
        public EmployeeController(IEmployeeService employee)
        {
            _employeeService = employee;
        }
        /// <summary>
        /// Getting the list of employees
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View(_employeeService.GetAll());
        }

        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Create new employe
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                Employee objEmployee = _employeeService.GetByName(employee.Name);
                if (objEmployee == null)
                {
                    _employeeService.InsertEmployee(employee);
                    _employeeService.Save();
                }
                else
                {
                    //this is just for testing, we have to make it from frontend side as per reqirement.
                    return Json($"{employee.Name} Already Exist, Name must be unique");
                }
            }
            return RedirectToAction("Index");
        }
        public IActionResult Details(int Id)
        {
            if (Id < 0)
            {
                return NotFound();
            }
            else
            {
                Employee objEmployee = _employeeService.GetById(Id);
                return View(objEmployee);
            }
        }

        public IActionResult Edit(int Id)
        {
            Employee objEmployee = _employeeService.GetById(Id);
            return View(objEmployee);
        }

        /// <summary>
        /// update employe info
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                _employeeService.UpdateEmployee(employee);
                _employeeService.Save();
            }
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int Id)
        {
            _employeeService.DeleteEmployee(Id);
            _employeeService.Save();
            return RedirectToAction("Index");

        }
    }
}
