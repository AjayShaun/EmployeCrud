﻿using ManageAppCrud.Data;
using ManageAppCrud.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManageAppCrud.Service
{
    public class EmployeeRepository : IEmployeeService
    {
        private readonly ApplicationContext _context;
        public EmployeeRepository(ApplicationContext context)
        {
            _context = context;
        }
        public void DeleteEmployee(int Id)
        {
            Employee emp = GetById(Id);
            _context.Remove(emp);
        }

        public IEnumerable<Employee> GetAll()
        {
            return _context.Employees.ToList();
        }

        public Employee GetById(int Id)
        {
            return _context.Employees.Where(a => a.Id == Id).FirstOrDefault();
        }

        public void InsertEmployee(Employee employee)
        {
            DateTime currentDate = DateTime.UtcNow;
            employee.CreatedDate = currentDate;
            employee.LastModifiedDate = currentDate;
            _context.Employees.Add(employee);
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public void UpdateEmployee(Employee employee)
        {
            DateTime currentDate = DateTime.UtcNow;
            employee.CreatedDate = currentDate;
            employee.LastModifiedDate = currentDate;
            _context.Employees.Update(employee);
        }

        public Employee GetByName(string Name)
        {
            return _context.Employees.Where(a => a.Name == Name).FirstOrDefault();
        }
    }
}
