﻿using ManageAppCrud.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManageAppCrud.Service
{
    public interface IEmployeeService
    {
        IEnumerable<Employee> GetAll();
        void Save();
        void InsertEmployee(Employee employee);
        void DeleteEmployee(int Id);
        void UpdateEmployee(Employee employee);
        Employee GetById(int Id);
        Employee GetByName(string Name);
    }
}
